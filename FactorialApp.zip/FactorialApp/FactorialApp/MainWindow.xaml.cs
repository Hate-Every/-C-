﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace FactorialApp
{
    public partial class MainWindow : Window
    {
        private const string DefaultInputText = "Введите число";
        public MainWindow()
        {
            InitializeComponent();
            InputTextBox.Text = DefaultInputText;
        }

        private void CalculateButton_Click(object sender, RoutedEventArgs e)
        {
            string input = InputTextBox.Text;

            // Проверка на пустой ввод
            if (string.IsNullOrEmpty(input) || input == DefaultInputText)
            {
                ResultTextBlock.Text = "Ошибка: Введите число!";
                return;
            }

            int number;
            //3.Проверка на ввод нечисловых символов
            if (!int.TryParse(input, out number))
            {
                ResultTextBlock.Text = "Ошибка: Некорректный ввод!";
                return;
            }

            else
            {
                number = int.Parse(input);
            }

            // Проверка на отрицательное число
            if (number < 0)
            {
                ResultTextBlock.Text = "Ошибка: Число должно быть положительным!";
                return;
            }

            try
            {
                long factorial = CalculateFactorial(number);
                ResultTextBlock.Text = $"Факториал: {factorial}";
            }
            catch (OverflowException)
            {
                ResultTextBlock.Text = "Ошибка: Переполнение!";
            }
        }

        private long CalculateFactorial(int number)
        {
            // Учитываем случай, когда число равно 0
            if (number == 0)
            {
                return 1;
            }

            long result = 1;
            // Обрабатываем переполнение внутри метода
            try
            {
                checked // Включаем проверку на переполнение
                {
                    for (int i = 1; i <= number; i++)
                    {
                        result *= i;
                    }
                }
            }
            catch (OverflowException)
            {
                throw;
            }
            return result;
        }

        //1
        private void InputTextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            if (InputTextBox.Text == "Введите число")
            {
                InputTextBox.Text = "";
            }
        }

        private void InputTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(InputTextBox.Text))
            {
                InputTextBox.Text = "Введите число";
            }
        }

    }
}
